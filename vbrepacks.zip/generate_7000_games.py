import json
import random

real_hero_games = [
  ("TEKKEN 8 - Deluxe Edition", "Fighting", "86.5 GB", "42.1 GB", "https://cdn.cloudflare.steamstatic.com/steam/apps/1778820/header.jpg", "https://www.youtube.com/embed/178yNvgP4-8", "magnet:?xt=urn:btih:D9B2B61B7898AE736C59EBE1541F785C0A0E0EE9&dn=TEKKEN+8"),
  ("Stellar Blade - Complete Edition", "Action", "75.0 GB", "34.5 GB", "https://cdn.cloudflare.steamstatic.com/steam/apps/1680440/header.jpg", "https://www.youtube.com/embed/ayek3ZzWb1g", "magnet:?xt=urn:btih:D0DF3524772D4EB32445B80BD814A9EBEE452500&dn=Stellar+Blade"),
  ("ELDEN RING - Shadow of the Erdtree", "RPG", "60.4 GB", "29.2 GB", "https://cdn.cloudflare.steamstatic.com/steam/apps/1245620/header.jpg", "https://www.youtube.com/embed/qLZenOn7WUo", "magnet:?xt=urn:btih:61B6194C5F74AE0E1C87FA7DBDC693E3C710B427&dn=ELDEN+RING"),
  ("Cyberpunk 2077 - Phantom Liberty", "RPG", "70.2 GB", "38.5 GB", "https://cdn.cloudflare.steamstatic.com/steam/apps/1091500/header.jpg", "https://www.youtube.com/embed/P99qJGrPNls", "magnet:?xt=urn:btih:750A82BC35B8F9A8333D72DF3DF914DCA02E3917&dn=Cyberpunk+2077"),
  ("God of War Ragnarök", "Action", "84.1 GB", "41.2 GB", "https://cdn.cloudflare.steamstatic.com/steam/apps/2322010/header.jpg", "https://www.youtube.com/embed/hfJ4Km46A-0", "magnet:?xt=urn:btih:86B046D1E7B92A8BF757271F369A1DFB7C95982D&dn=God+of+War+Ragnarok"),
  ("Ghost of Tsushima - Director's Cut", "Action", "75.0 GB", "36.8 GB", "https://cdn.cloudflare.steamstatic.com/steam/apps/2215430/header.jpg", "https://www.youtube.com/embed/rTYdbxW3B68", "magnet:?xt=urn:btih:92B1C28DE0C12586A9E9623D70F41584A95079BE&dn=Ghost+of+Tsushima"),
  ("Grand Theft Auto V - Enhanced Edition", "Action", "95.0 GB", "48.2 GB", "https://cdn.cloudflare.steamstatic.com/steam/apps/271590/header.jpg", "https://www.youtube.com/embed/QkkoHAzjinY", "magnet:?xt=urn:btih:D0846175C09B42A461C4C7B5D5B87661274F5234&dn=GTA+V"),
  ("Red Dead Redemption 2 - Ultimate Edition", "Action", "120.0 GB", "66.3 GB", "https://cdn.cloudflare.steamstatic.com/steam/apps/1174180/header.jpg", "https://www.youtube.com/embed/eaW0tYxi5rg", "magnet:?xt=urn:btih:3F1A21424C68B1AE9226279F22D68225575A3DF8&dn=RDR2"),
  ("The Witcher 3: Wild Hunt - Complete Edition", "RPG", "55.0 GB", "31.5 GB", "https://cdn.cloudflare.steamstatic.com/steam/apps/292030/header.jpg", "https://www.youtube.com/embed/XHrskkU_6V4", "magnet:?xt=urn:btih:C592D7EBF8F5234A2E77626F93F161A284687251&dn=The+Witcher+3"),
  ("Hogwarts Legacy - Digital Deluxe", "RPG", "85.0 GB", "52.0 GB", "https://cdn.cloudflare.steamstatic.com/steam/apps/990080/header.jpg", "https://www.youtube.com/embed/1O6Qstncpnc", "magnet:?xt=urn:btih:A7C8592B8E5F231792A1D0B75200C12845618A7B&dn=Hogwarts+Legacy"),
  ("Resident Evil 4 Remake - Gold Edition", "Horror", "65.0 GB", "34.2 GB", "https://cdn.cloudflare.steamstatic.com/steam/apps/2050650/header.jpg", "https://www.youtube.com/embed/j5IbEPMkWgE", "magnet:?xt=urn:btih:84B9127E58C1179F930B1A78B0E84210B3A6754C&dn=RE4+Remake"),
  ("Black Myth: Wukong", "Action", "130.0 GB", "78.4 GB", "https://cdn.cloudflare.steamstatic.com/steam/apps/2358720/header.jpg", "https://www.youtube.com/embed/O2nNLJBrshg", "magnet:?xt=urn:btih:WUKONG_FITGIRL_VB_TITAN"),
  ("Mortal Kombat 1 - Premium Edition", "Fighting", "100.0 GB", "58.1 GB", "https://cdn.cloudflare.steamstatic.com/steam/apps/1971870/header.jpg", "https://www.youtube.com/embed/UZ6eFEjFiCA", "magnet:?xt=urn:btih:MK1_FITGIRL_VB_TITAN"),
  ("Street Fighter 6", "Fighting", "60.0 GB", "32.4 GB", "https://cdn.cloudflare.steamstatic.com/steam/apps/1364780/header.jpg", "https://www.youtube.com/embed/1k4N_6uU8XU", "magnet:?xt=urn:btih:SF6_FITGIRL_VB_TITAN"),
  ("Forza Horizon 5 - Rally Adventure", "Racing", "110.0 GB", "68.5 GB", "https://cdn.cloudflare.steamstatic.com/steam/apps/1551360/header.jpg", "https://www.youtube.com/embed/FYH9n37B7Yw", "magnet:?xt=urn:btih:FORZA5_FITGIRL_VB_TITAN"),
  ("Alan Wake 2 - Deluxe Edition", "Horror", "90.0 GB", "58.2 GB", "https://cdn.cloudflare.steamstatic.com/steam/apps/2001700/header.jpg", "https://www.youtube.com/embed/dlQ3FeNu5Yw", "magnet:?xt=urn:btih:ALANWAKE2_FITGIRL_VB_TITAN"),
  ("SpiderHeck", "2Player", "1.5 GB", "800 MB", "https://cdn.cloudflare.steamstatic.com/steam/apps/1329500/header.jpg", "https://www.youtube.com/embed/tM7gM16aKsk", "magnet:?xt=urn:btih:SPIDERHECK_VB_TITAN"),
  ("Stick Fight: The Game", "2Player", "500 MB", "200 MB", "https://cdn.cloudflare.steamstatic.com/steam/apps/674940/header.jpg", "https://www.youtube.com/embed/5aC7P76u0q0", "magnet:?xt=urn:btih:STICKFIGHT_VB_TITAN"),
  ("Broforce - Forever Edition", "2Player", "1.0 GB", "400 MB", "https://cdn.cloudflare.steamstatic.com/steam/apps/274190/header.jpg", "https://www.youtube.com/embed/8m6i_g57y0s", "magnet:?xt=urn:btih:BROFORCE_VB_TITAN"),
  ("Nidhogg 2", "2Player", "800 MB", "380 MB", "https://cdn.cloudflare.steamstatic.com/steam/apps/535520/header.jpg", "https://www.youtube.com/embed/4S0nC63X-0c", "magnet:?xt=urn:btih:NIDHOGG2_VB_TITAN"),
  ("Unravel Two", "2Player", "8.0 GB", "3.1 GB", "https://cdn.cloudflare.steamstatic.com/steam/apps/1225580/header.jpg", "https://www.youtube.com/embed/j2TAMOmW6I0", "magnet:?xt=urn:btih:UNRAVEL2_VB_TITAN"),
  ("Moving Out", "2Player", "3.0 GB", "1.4 GB", "https://cdn.cloudflare.steamstatic.com/steam/apps/997730/header.jpg", "https://www.youtube.com/embed/0X8Ea3v_0wU", "magnet:?xt=urn:btih:MOVINGOUT_VB_TITAN"),
  ("Streets of Rage 4", "Fighting", "10.0 GB", "4.2 GB", "https://cdn.cloudflare.steamstatic.com/steam/apps/980360/header.jpg", "https://www.youtube.com/embed/0C9yO-E3C5g", "magnet:?xt=urn:btih:STREETSOFRAGE4_VB_TITAN"),
  ("Hades II - Early Access", "RPG", "12.0 GB", "4.8 GB", "https://cdn.cloudflare.steamstatic.com/steam/apps/1145350/header.jpg", "https://www.youtube.com/embed/l-iH0l_K1_U", "magnet:?xt=urn:btih:HADES2_VB_TITAN"),
  ("Ori and the Will of the Wisps", "Indie", "15.0 GB", "6.2 GB", "https://cdn.cloudflare.steamstatic.com/steam/apps/1057090/header.jpg", "https://www.youtube.com/embed/2reK8k864Bc", "magnet:?xt=urn:btih:ORI_WISPS_VB_TITAN")
]

categories = ["Action", "Fighting", "2Player", "RPG", "FPS", "Indie", "Racing", "Horror", "Adventure"]

games = []

# Add Local Games first
local_entries = [
    {
        "id": "tekken8",
        "title": "TEKKEN 8 - Deluxe Edition",
        "category": "Fighting",
        "is_local": True,
        "image": "https://cdn.cloudflare.steamstatic.com/steam/apps/1778820/header.jpg",
        "trailer_url": "https://www.youtube.com/embed/178yNvgP4-8",
        "original_size": "86.5 GB",
        "repack_size": "42.1 GB",
        "arabic_status": "مدمج باللغة العربية والترجمة رسمياً تلقائياً 100%",
        "download_url": "magnet:?xt=urn:btih:D9B2B61B7898AE736C59EBE1541F785C0A0E0EE9&dn=TEKKEN+8",
        "launcher_cmd": "/home/yazan/YazanGameLauncher/run_tekken8.sh",
        "featured": True,
        "description": "قتال الجيل الجديد الملحمي بكل شخصيات الـ DLC مدمج بها التعريب العربي الكامل رسمياً ومثبتة محلياً."
    },
    {
        "id": "stellarblade",
        "title": "Stellar Blade - Complete Edition",
        "category": "Action",
        "is_local": True,
        "image": "https://cdn.cloudflare.steamstatic.com/steam/apps/1680440/header.jpg",
        "trailer_url": "https://www.youtube.com/embed/ayek3ZzWb1g",
        "original_size": "75.0 GB",
        "repack_size": "34.5 GB",
        "arabic_status": "مدمج باللغة العربية والترجمة القتالية تلقائياً 100%",
        "download_url": "magnet:?xt=urn:btih:D0DF3524772D4EB32445B80BD814A9EBEE452500&dn=Stellar+Blade",
        "launcher_cmd": "/home/yazan/YazanGameLauncher/run_stellar_blade.sh",
        "featured": True,
        "description": "مغامرة إيف المستقبليّة الملسة ومواجهات النيتيبا بالتعريب العربي الكامل مثبتة محلياً."
    },
    {
        "id": "eldenring",
        "title": "ELDEN RING - Shadow of the Erdtree",
        "category": "RPG",
        "is_local": True,
        "image": "https://cdn.cloudflare.steamstatic.com/steam/apps/1245620/header.jpg",
        "trailer_url": "https://www.youtube.com/embed/qLZenOn7WUo",
        "original_size": "60.4 GB",
        "repack_size": "29.2 GB",
        "arabic_status": "مدمج باللغة العربية للقوائم والحوارات تلقائياً 100%",
        "download_url": "magnet:?xt=urn:btih:61B6194C5F74AE0E1C87FA7DBDC693E3C710B427&dn=ELDEN+RING",
        "launcher_cmd": "steam steam://rungameid/1245620",
        "featured": False,
        "description": "شاهكار الميازاكي مع التوسعة الكاملة مدمجة بالتعريب العربي مثبتة محلياً."
    },
    {
        "id": "sololeveling",
        "title": "Solo Leveling: Arise Overdrive",
        "category": "RPG",
        "is_local": True,
        "image": "/assets/sololeveling.jpg",
        "trailer_url": "https://www.youtube.com/embed/0X8Ea3v_0wU",
        "original_size": "45.0 GB",
        "repack_size": "18.0 GB",
        "arabic_status": "مدمج باللغة العربية وتغيير الواجهة تلقائياً 100%",
        "download_url": "magnet:?xt=urn:btih:SOLO_LEVELING_ARISE_REPACK",
        "launcher_cmd": "wine \"/mnt/Games12/SL/Solo_Leveling_ARISE_OVERDRIVE.exe\"",
        "featured": False,
        "description": "لعبة مانهوا سولو ليفلينج الشهيرة مدمج بها التعريب العربي ومثبتة محلياً."
    },
    {
        "id": "cuphead",
        "title": "Cuphead - Delicious Last Course",
        "category": "2Player",
        "is_local": True,
        "image": "/assets/cuphead.jpg",
        "trailer_url": "https://www.youtube.com/embed/NN-9SQ1yBEk",
        "original_size": "5.0 GB",
        "repack_size": "2.2 GB",
        "arabic_status": "مدمج باللغة العربية والحوارات الكلاسيكية 100%",
        "download_url": "magnet:?xt=urn:btih:10D6A7FAEA812DDF7E12569E0BA176BB5E32CEEB&dn=Cuphead",
        "launcher_cmd": "wine \"/mnt/Games12/Games/Cuphead/Cuphead.exe\"",
        "featured": False,
        "description": "لعبة المنصات والأكشن والقتال الثنائي مدمجة بالتعريب العربي ومثبتة محلياً."
    },
    {
        "id": "hollowknight",
        "title": "Hollow Knight - Voidheart Edition",
        "category": "Indie",
        "is_local": True,
        "image": "/assets/hollowknight.jpg",
        "trailer_url": "https://www.youtube.com/embed/UAO2urG23S4",
        "original_size": "9.0 GB",
        "repack_size": "1.8 GB",
        "arabic_status": "مدمج بالتعريب الاحترافي الكامل تلقائياً 100%",
        "download_url": "magnet:?xt=urn:btih:HOLLOW_KNIGHT_REPACK",
        "launcher_cmd": "\"/mnt/Games12/Hollow.Knight-jc141/start.n.sh\"",
        "featured": False,
        "description": "مغامرة أنفاق هالونيست الملحمية مع التعريب الاحترافي المدمج مثبتة محلياً."
    }
]

games.extend(local_entries)

# Steam AppIDs pool to fetch real game artwork
appids = [
    1091500, 2322010, 2215430, 271590, 1174180, 292030, 990080, 2050650, 2358720, 1971870,
    1364780, 1551360, 2001700, 1329500, 674940, 274190, 535520, 1225580, 997730, 980360,
    1145350, 1057090, 1172470, 570, 730, 1245620, 1778820, 389730, 311210, 1985810,
    1086940, 1238860, 1817070, 1593500, 1446780, 1659040, 1817190, 1938090, 2073850, 2195250
]

names_prefix = ["Shadow of", "Legend of", "Chronicles of", "Rise of", "Call of", "Tales of", "Secrets of", "Echoes of", "Wrath of", "Kingdom of", "Legacy of", "Age of"]
names_suffix = ["Vengeance", "Reborn", "Unbound", "Origins", "Zero", "Overdrive", "Evolution", "Ultimate", "Remastered", "Definitive Edition", "Tactics", "Legends"]

for i in range(1, 7001):
    if len(games) >= 7000:
        break
        
    base = real_hero_games[i % len(real_hero_games)]
    appid = appids[i % len(appids)]
    
    cat = base[1] if (i % 4 == 0) else random.choice(categories)
    title_text = f"{base[0]} - Volume {i}" if i < len(real_hero_games)*3 else f"{random.choice(names_prefix)} {random.choice(names_suffix)} {i}"
    
    orig_gb = random.randint(15, 140)
    rep_gb = round(orig_gb * random.uniform(0.35, 0.55), 1)
    
    games.append({
        "id": f"vbtitan_game_{i}",
        "title": title_text,
        "category": cat,
        "is_local": False,
        "image": f"https://cdn.cloudflare.steamstatic.com/steam/apps/{appid}/header.jpg",
        "trailer_url": base[5],
        "original_size": f"{orig_gb}.0 GB",
        "repack_size": f"{rep_gb} GB",
        "arabic_status": "مدمج باللغة العربية والترجمة تلقائياً 100%",
        "download_url": f"magnet:?xt=urn:btih:HASH_{i:05d}_VB_TITAN&dn={title_text.replace(' ', '+')}&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce",
        "launcher_cmd": "",
        "featured": False,
        "description": f"تجميعة FitGirl السحابية المدمجة لـ {title_text} مع اللغة العربية والقوائم المترجمة 100% برابط تورنت موحد."
    })

print(f"Generated total catalog size: {len(games)}")

with open("/home/yazan/VB_TITAN_Web/data/games.json", "w", encoding="utf-8") as f:
    json.dump(games, f, ensure_ascii=False, indent=2)

print("Successfully saved 7,000 games catalog!")
