#!/usr/bin/env python3
import json
import re
import urllib.parse

GAMES_JSON_PATH = '/home/yazan/.gemini/antigravity/scratch/vbrepacks/data/games.json'
INDEX_HTML_PATH = '/home/yazan/.gemini/antigravity/scratch/vbrepacks/templates/index.html'
SCRIPT_JS_PATH = '/home/yazan/.gemini/antigravity/scratch/vbrepacks/static/script.js'

def clean_games_json():
    print("🧹 Cleaning data/games.json...")
    with open(GAMES_JSON_PATH, 'r', encoding='utf-8') as f:
        games = json.load(f)

    cleaned_count = 0
    for game in games:
        # 1. Clean ID
        if 'fitgirl_strict_' in game.get('id', ''):
            game['id'] = game['id'].replace('fitgirl_strict_', 'vb_game_')
        elif 'fitgirl' in game.get('id', ''):
            game['id'] = re.sub(r'fitgirl_?', 'vb_', game['id'], flags=re.IGNORECASE)

        # 2. Clean Description
        desc = game.get('description', '')
        desc = desc.replace(' من FitGirl Repacks.', '.')
        desc = desc.replace(' من FitGirl Repacks', '')
        desc = desc.replace('من FitGirl Repacks', '')
        desc = desc.replace('FitGirl Repacks', 'التجميعة الرسمية')
        desc = desc.replace('FitGirl', 'التجميعة الرسمية')
        game['description'] = desc

        # 3. Clean Download URL -> Convert to Direct Torrent Search (1337x / TorrentGalaxy)
        url = game.get('download_url', '')
        if 'fitgirl-repacks.site' in url:
            # Extract search query
            title = game.get('title', '')
            query = urllib.parse.quote_plus(title)
            # Use direct 1337x / Torrent search for torrent download
            game['download_url'] = f"https://1337x.to/search/{query}/1/"
        elif 'fitgirl' in url.lower():
            title = game.get('title', '')
            query = urllib.parse.quote_plus(title)
            game['download_url'] = f"https://1337x.to/search/{query}/1/"

        cleaned_count += 1

    with open(GAMES_JSON_PATH, 'w', encoding='utf-8') as f:
        json.dump(games, f, ensure_ascii=False, indent=2)

    print(f"✅ Successfully cleaned {cleaned_count} games in games.json!")

def clean_index_html():
    print("🧹 Cleaning templates/index.html...")
    with open(INDEX_HTML_PATH, 'r', encoding='utf-8') as f:
        content = f.read()

    content = content.replace('ألعاب FitGirl', 'الألعاب')
    content = content.replace('FitGirl', 'الألعاب')
    content = content.replace('نسخة FitGirl', 'النسخة الرسمية')
    content = content.replace('تجميعة FitGirl', 'التجميعة الرسمية')

    with open(INDEX_HTML_PATH, 'w', encoding='utf-8') as f:
        f.write(content)
    print("✅ Successfully cleaned index.html!")

def clean_script_js():
    print("🧹 Cleaning static/script.js...")
    with open(SCRIPT_JS_PATH, 'r', encoding='utf-8') as f:
        content = f.read()

    content = content.replace('ألعاب FitGirl', 'الألعاب')
    content = content.replace('FitGirl', 'الألعاب')
    content = content.replace('تجميعة FitGirl', 'تجميعة الألعاب')

    with open(SCRIPT_JS_PATH, 'w', encoding='utf-8') as f:
        f.write(content)
    print("✅ Successfully cleaned script.js!")

if __name__ == '__main__':
    clean_games_json()
    clean_index_html()
    clean_script_js()
    print("🎉 All FitGirl references successfully removed!")
