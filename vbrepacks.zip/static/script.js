let allSiteGames = [];
let currentFilterMode = 'all';
let selectedGameForDl = null;

document.addEventListener('DOMContentLoaded', () => {
    loadSiteGames();
});

async function loadSiteGames() {
    try {
        const res = await fetch('/api/games');
        allSiteGames = await res.json();
        
        // Count local installed games
        const localGames = allSiteGames.filter(g => g.is_local);
        const localCountBadge = document.getElementById('local-count');
        if (localCountBadge) localCountBadge.innerText = localGames.length;

        renderPortalGrid();
        if (allSiteGames.length > 0) {
            setupSiteHero(allSiteGames[0]);
        }
    } catch (err) {
        console.error("Error loading games:", err);
    }
}

let displayedCount = 60;
let currentFilteredGames = [];

function renderPortalGrid(resetCount = true) {
    const grid = document.getElementById('main-games-grid');
    if (!grid) return;
    
    if (resetCount) {
        displayedCount = 60;
        grid.innerHTML = '';
    }

    const query = (document.getElementById('portal-search')?.value || '').toLowerCase().trim();

    currentFilteredGames = allSiteGames.filter(g => {
        let matchesFilter = false;
        if (currentFilterMode === 'all') matchesFilter = true;
        else if (currentFilterMode === 'local') matchesFilter = g.is_local;
        else if (currentFilterMode === 'cloud') matchesFilter = !g.is_local;
        else matchesFilter = (g.category || '').toLowerCase().includes(currentFilterMode.toLowerCase());

        const matchesSearch = (g.title || '').toLowerCase().includes(query) || (g.category || '').toLowerCase().includes(query);
        return matchesFilter && matchesSearch;
    });

    const counter = document.getElementById('section-counter-text');
    if (counter) counter.innerText = `عرض ${Math.min(displayedCount, currentFilteredGames.length)} من أصل ${currentFilteredGames.length.toLocaleString('ar-EG')} لعبة`;

    if (currentFilteredGames.length === 0) {
        grid.innerHTML = `
            <div style="grid-column: 1/-1; text-align: center; padding: 60px; color: var(--text-muted);">
                <i class="fa-solid fa-ghost" style="font-size: 3rem; margin-bottom: 12px; color: var(--cyan);"></i>
                <p>لا توجد ألعاب مطابقة لهذا الفلتر حالياً.</p>
            </div>
        `;
        return;
    }

    const itemsToRender = currentFilteredGames.slice(grid.children.length, displayedCount);
    
    itemsToRender.forEach(game => {
        const card = document.createElement('div');
        card.className = 'portal-card';
        card.onclick = () => openDlModal(game);
        card.innerHTML = `
            <div class="card-thumb">
                <img src="${game.image}" alt="${game.title}" loading="lazy" onerror="this.src='/assets/logo.png'">
                <span class="card-arabic-badge"><i class="fa-solid fa-check"></i> ${game.is_local ? 'مثبتة محلياً' : 'مدمج بالتعريب 100%'}</span>
            </div>
            <div class="card-details">
                <div class="card-title-text">${game.title}</div>
                <div class="card-size-row">
                    <span>${game.original_size}</span>
                    <span class="repack-val">مضغوطة: ${game.repack_size}</span>
                </div>
                <button class="btn-open-dl" style="${game.is_local ? 'background: rgba(16, 185, 129, 0.2); border-color: #10b981;' : ''}">
                    <i class="fa-solid ${game.is_local ? 'fa-play' : 'fa-cloud-arrow-down'}"></i> ${game.is_local ? 'تشغيل / فتح اللعبة' : 'تحميل اللعبة مع التعريب'}
                </button>
            </div>
        `;
        grid.appendChild(card);
    });

    // Remove existing load more btn container if any
    let oldLoadBtn = document.getElementById('load-more-container');
    if (oldLoadBtn) oldLoadBtn.remove();

    if (displayedCount < currentFilteredGames.length) {
        const loadContainer = document.createElement('div');
        loadContainer.id = 'load-more-container';
        loadContainer.style.cssText = 'grid-column: 1/-1; text-align: center; padding: 30px 0;';
        loadContainer.innerHTML = `
            <button id="btn-load-more" onclick="loadMoreGames()" style="background: linear-gradient(135deg, var(--cyan), #2563eb); border: none; color: white; padding: 14px 36px; border-radius: 30px; font-weight: 700; cursor: pointer; font-size: 1.05rem; box-shadow: 0 0 20px rgba(6,182,212,0.4); transition: transform 0.2s;">
                <i class="fa-solid fa-plus-circle"></i> عرض المزيد من الألعاب (متبقي ${ (currentFilteredGames.length - displayedCount).toLocaleString('ar-EG') })
            </button>
        `;
        grid.appendChild(loadContainer);
    }
}

function loadMoreGames() {
    displayedCount += 60;
    renderPortalGrid(false);
}

// Add infinite scroll listener
window.addEventListener('scroll', () => {
    if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 800) {
        if (currentFilteredGames && displayedCount < currentFilteredGames.length) {
            displayedCount += 60;
            renderPortalGrid(false);
        }
    }
});

function setupSiteHero(game) {
    const hero = document.getElementById('portal-hero');
    if (!hero) return;
    hero.style.backgroundImage = `url('${game.image}')`;
    document.getElementById('hero-title').innerText = game.title;
    document.getElementById('hero-desc').innerText = game.description || 'تجميعة مخصصة بالتعريب المدمج تلقائياً 100%.';
    document.getElementById('hero-orig').innerText = game.original_size || '60 GB';
    document.getElementById('hero-repack').innerText = game.repack_size || '25 GB';
    
    document.getElementById('hero-dl-btn').onclick = () => openDlModal(game);
    document.getElementById('hero-launch-btn').onclick = () => launchGameLocal(game.id);
}

function openDlModal(game) {
    selectedGameForDl = game;
    document.getElementById('modal-game-title').innerHTML = `<i class="fa-solid fa-gamepad"></i> ${game.title}`;
    document.getElementById('modal-game-desc').innerText = game.description || 'تجميعة FitGirl مدمجة بالتعريب العربي الكامل تلقائياً.';
    document.getElementById('modal-arabic-tag').innerText = `✨ ${game.arabic_status || 'مدمج باللغة العربية والترجمة 100% مسبقاً'}`;

    // Set YouTube Trailer Video
    const videoFrame = document.getElementById('modal-video-frame');
    const videoWrapper = document.getElementById('video-wrapper');
    if (game.trailer_url) {
        videoFrame.src = game.trailer_url;
        videoWrapper.style.display = 'block';
    } else {
        videoFrame.src = '';
        videoWrapper.style.display = 'none';
    }

    const singleUrl = game.download_url || '#';
    document.getElementById('modal-single-dl').href = singleUrl;

    const launchBtn = document.getElementById('modal-btn-launch');
    if (game.is_local) {
        launchBtn.style.display = 'flex';
    } else {
        launchBtn.style.display = 'none';
    }

    document.getElementById('dl-modal').classList.add('active');
}

function closeDlModal() {
    const videoFrame = document.getElementById('modal-video-frame');
    if (videoFrame) videoFrame.src = '';
    document.getElementById('dl-modal').classList.remove('active');
}

async function triggerLocalLaunch() {
    if (selectedGameForDl) {
        launchGameLocal(selectedGameForDl.id);
        closeDlModal();
    }
}

async function launchGameLocal(id) {
    showToast('جاري إرسال أمر التشغيل لللانشر المحلي...', 'fa-rocket');
    try {
        const res = await fetch(`/api/launch/${id}`, { method: 'POST' });
        const data = await res.json();
        if (data.success) {
            showToast(data.message, 'fa-circle-check');
        } else {
            showToast(data.error || 'غير متوفرة محلياً', 'fa-triangle-exclamation', '#ef4444');
        }
    } catch (err) {
        showToast('تعذر الاتصال بـ VB Launcher', 'fa-triangle-exclamation', '#ef4444');
    }
}

function selectSidebarFilter(filter, el) {
    currentFilterMode = filter;
    document.querySelectorAll('.sidebar-link').forEach(link => link.classList.remove('active'));
    if (el) el.classList.add('active');

    const heading = document.getElementById('section-heading-text');
    if (heading) {
        let labelText = "كل الألعاب المعربة";
        if (filter === 'local') labelText = "ألعابي المثبتة محلياً";
        else if (filter === 'cloud') labelText = "مكتبة ألعاب FitGirl السحابية";
        else if (filter === '2Player') labelText = "🎮 ألعاب ثنائية و1v1";
        else if (filter === 'Action') labelText = "⚔️ ألعاب أكشن ومغامرات";
        else if (filter === 'Fighting') labelText = "🥊 ألعاب قتال";
        else if (filter === 'RPG') labelText = "🐉 ألعاب آر بي جي RPG";
        else if (filter === 'Horror') labelText = "👻 ألعاب رعب واستكشاف";
        else if (filter === 'Racing') labelText = "🏎️ ألعاب سباقات وسيارات";

        heading.innerHTML = `<i class="fa-solid fa-layer-group" style="color: var(--cyan);"></i> ${labelText}`;
    }

    renderPortalGrid();
}

function filterPortalGames() {
    renderPortalGrid();
}

function showToast(msg, icon = 'fa-circle-check', bg = '#10b981') {
    const toast = document.getElementById('toast-popup');
    const toastMsg = document.getElementById('toast-msg');
    const toastIcon = document.getElementById('toast-icon');

    if (!toast) return;
    toastMsg.innerText = msg;
    toastIcon.className = `fa-solid ${icon}`;
    toast.style.background = bg;
    toast.classList.add('show');

    setTimeout(() => {
        toast.classList.remove('show');
    }, 4000);
}
