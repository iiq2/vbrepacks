import json
import random

categories = ["Action", "Fighting", "2Player", "RPG", "FPS", "Indie", "Racing", "Horror", "Strategy", "Adventure"]

# High-profile game templates to replicate realistic game catalog
base_games = [
    ("TEKKEN 8 - Deluxe Edition", "Fighting", "86 GB", "42 GB", "magnet:?xt=urn:btih:D9B2B61B7898AE736C59EBE1541F785C0A0E0EE9&dn=TEKKEN+8"),
    ("Stellar Blade - Complete Edition", "Action", "75 GB", "34.5 GB", "magnet:?xt=urn:btih:D0DF3524772D4EB32445B80BD814A9EBEE452500&dn=Stellar+Blade"),
    ("ELDEN RING - Shadow of the Erdtree", "RPG", "60 GB", "29 GB", "magnet:?xt=urn:btih:61B6194C5F74AE0E1C87FA7DBDC693E3C710B427&dn=Elden+Ring"),
    ("Cyberpunk 2077 - Phantom Liberty", "RPG", "70 GB", "38.5 GB", "magnet:?xt=urn:btih:750A82BC35B8F9A8333D72DF3DF914DCA02E3917&dn=Cyberpunk+2077"),
    ("God of War Ragnarök", "Action", "84 GB", "41.2 GB", "magnet:?xt=urn:btih:86B046D1E7B92A8BF757271F369A1DFB7C95982D&dn=God+of+War+Ragnarok"),
    ("Ghost of Tsushima - Director's Cut", "Action", "75 GB", "36.8 GB", "magnet:?xt=urn:btih:92B1C28DE0C12586A9E9623D70F41584A95079BE&dn=Ghost+of+Tsushima"),
    ("Grand Theft Auto V - Enhanced Edition", "Action", "95 GB", "48 GB", "magnet:?xt=urn:btih:GTA5_ENHANCED_VB_TITAN"),
    ("SpiderHeck", "2Player", "1.5 GB", "800 MB", "magnet:?xt=urn:btih:SPIDERHECK_VB_TITAN"),
    ("Stick Fight: The Game", "2Player", "500 MB", "200 MB", "magnet:?xt=urn:btih:STICKFIGHT_VB_TITAN"),
    ("Broforce - Forever Edition", "2Player", "1 GB", "400 MB", "magnet:?xt=urn:btih:BROFORCE_VB_TITAN"),
    ("Nidhogg 2", "2Player", "800 MB", "380 MB", "magnet:?xt=urn:btih:NIDHOGG2_VB_TITAN"),
    ("Unravel Two", "2Player", "8 GB", "3.1 GB", "magnet:?xt=urn:btih:UNRAVEL2_VB_TITAN"),
    ("Moving Out", "2Player", "3 GB", "1.4 GB", "magnet:?xt=urn:btih:MOVINGOUT_VB_TITAN"),
    ("Streets of Rage 4", "Fighting", "10 GB", "4.2 GB", "magnet:?xt=urn:btih:STREETSOFRAGE4_VB_TITAN"),
    ("Hades II - Early Access", "RPG", "12 GB", "4.8 GB", "magnet:?xt=urn:btih:HADES2_VB_TITAN"),
    ("Ori and the Will of the Wisps", "Indie", "15 GB", "6.2 GB", "magnet:?xt=urn:btih:ORI_WISPS_VB_TITAN"),
    ("Red Dead Redemption 2", "Action", "120 GB", "66 GB", "magnet:?xt=urn:btih:RDR2_VB_TITAN"),
    ("The Witcher 3: Wild Hunt - Complete", "RPG", "55 GB", "31 GB", "magnet:?xt=urn:btih:WITCHER3_VB_TITAN"),
    ("Hogwarts Legacy - Digital Deluxe", "RPG", "85 GB", "52 GB", "magnet:?xt=urn:btih:HOGWARTS_VB_TITAN"),
    ("Resident Evil 4 Remake", "Horror", "65 GB", "34 GB", "magnet:?xt=urn:btih:RE4_REMAKE_VB_TITAN"),
    ("Resident Evil Village - Gold Edition", "Horror", "35 GB", "21 GB", "magnet:?xt=urn:btih:RE8_VB_TITAN"),
    ("Marvel's Spider-Man Remastered", "Action", "75 GB", "38 GB", "magnet:?xt=urn:btih:SPIDERMAN_VB_TITAN"),
    ("Marvel's Spider-Man: Miles Morales", "Action", "45 GB", "24 GB", "magnet:?xt=urn:btih:MILES_MORALES_VB_TITAN"),
    ("Black Myth: Wukong", "Action", "130 GB", "78 GB", "magnet:?xt=urn:btih:WUKONG_VB_TITAN"),
    ("Mortal Kombat 1 - Premium Edition", "Fighting", "100 GB", "58 GB", "magnet:?xt=urn:btih:MK1_VB_TITAN"),
    ("Street Fighter 6", "Fighting", "60 GB", "32 GB", "magnet:?xt=urn:btih:SF6_VB_TITAN"),
    ("Forza Horizon 5 - Rally Adventure", "Racing", "110 GB", "68 GB", "magnet:?xt=urn:btih:FH5_VB_TITAN"),
    ("Need for Speed Unbound", "Racing", "45 GB", "26 GB", "magnet:?xt=urn:btih:NFS_UNBOUND_VB_TITAN"),
    ("Call of Duty: Modern Warfare II", "FPS", "125 GB", "72 GB", "magnet:?xt=urn:btih:COD_MW2_VB_TITAN"),
    ("Battlefield 2042", "FPS", "90 GB", "54 GB", "magnet:?xt=urn:btih:BF2042_VB_TITAN"),
    ("Alan Wake 2 - Deluxe Edition", "Horror", "90 GB", "58 GB", "magnet:?xt=urn:btih:ALAN_WAKE2_VB_TITAN"),
    ("Dead Space Remake", "Horror", "50 GB", "31 GB", "magnet:?xt=urn:btih:DEAD_SPACE_REMAKE_VB_TITAN"),
    ("Lies of P", "RPG", "50 GB", "28 GB", "magnet:?xt=urn:btih:LIES_OF_P_VB_TITAN"),
    ("Sekiro: Shadows Die Twice - GOTY", "Action", "25 GB", "14 GB", "magnet:?xt=urn:btih:SEKIRO_VB_TITAN"),
    ("Dark Souls III - The Ringed City", "RPG", "25 GB", "16 GB", "magnet:?xt=urn:btih:DS3_VB_TITAN"),
    ("It Takes Two", "2Player", "50 GB", "28 GB", "magnet:?xt=urn:btih:IT_TAKES_TWO_VB_TITAN"),
    ("Overcooked! All You Can Eat", "2Player", "10 GB", "4.5 GB", "magnet:?xt=urn:btih:OVERCOOKED_AYCE_VB_TITAN"),
    ("Cuphead - Delicious Last Course", "2Player", "5 GB", "2.2 GB", "magnet:?xt=urn:btih:CUPHEAD_VB_TITAN"),
    ("Hollow Knight - Voidheart Edition", "Indie", "9 GB", "1.8 GB", "magnet:?xt=urn:btih:HOLLOWKNIGHT_VB_TITAN"),
    ("Dead Cells - Return to Castlevania", "Indie", "4 GB", "1.5 GB", "magnet:?xt=urn:btih:DEAD_CELLS_VB_TITAN")
]

# Local games list to preserve
local_ids = ["tekken8", "stellarblade", "eldenring", "sololeveling", "cuphead", "hollowknight"]

games_list = []

# First add exact local games
for g in base_games:
    if g[0].startswith("TEKKEN 8"):
        games_list.append({
            "id": "tekken8", "title": g[0], "category": g[1], "is_local": True, "image": "/assets/tekken8.jpg",
            "original_size": g[2], "repack_size": g[3], "arabic_status": "مدمج باللغة العربية والترجمة رسمياً تلقائياً 100%",
            "download_url": g[4], "launcher_cmd": "/home/yazan/YazanGameLauncher/run_tekken8.sh", "featured": True,
            "description": "نسخة FitGirl المدمجة بالكامل مع الترجمة والقوائم العربية الرسمية والشخصيات الإضافية مثبتة محلياً."
        })
    elif g[0].startswith("Stellar Blade"):
        games_list.append({
            "id": "stellarblade", "title": g[0], "category": g[1], "is_local": True, "image": "/assets/stellarblade.jpg",
            "original_size": g[2], "repack_size": g[3], "arabic_status": "مدمج باللغة العربية والترجمة القتالية تلقائياً 100%",
            "download_url": g[4], "launcher_cmd": "/home/yazan/YazanGameLauncher/run_stellar_blade.sh", "featured": True,
            "description": "نسخة FitGirl الشاملة لمغامرة إيف المستقبليّة مدمج بها التعريب العربي الكامل مثبتة محلياً."
        })

# Generate 2000 total games
genres = ["Action", "Fighting", "2Player", "RPG", "FPS", "Indie", "Racing", "Horror", "Strategy", "Adventure"]
game_words = ["Chronicles", "Legacy", "Reborn", "Evolution", "Warfare", "Overdrive", "Remastered", "Definitive", "Odyssey", "Unbound", "Rising", "Zero", "Unleashed", "Origins", "Tactics", "Legends"]
prefixes = ["Shadow of", "Kingdom of", "Legend of", "Age of", "Call of", "Rise of", "Echoes of", "Wrath of", "Secrets of", "Tales of"]

for i in range(1, 2001):
    if len(games_list) >= 2000:
        break
        
    base = base_games[i % len(base_games)]
    cat = base[1] if (i % 3 == 0) else random.choice(genres)
    
    title_name = f"{random.choice(prefixes)} {random.choice(game_words)} {i}" if i > len(base_games) else base[0]
    orig_s = f"{random.randint(10, 120)} GB"
    rep_s = f"{random.randint(2, 50)} GB"
    hash_code = f"HASH_{i:04d}_VB_TITAN"
    
    img_url = base[4] if "/assets/" in base[4] else f"https://cdn.cloudflare.steamstatic.com/steam/apps/{100000 + (i*15) % 1500000}/header.jpg"
    
    games_list.append({
        "id": f"fitgirl_game_{i}",
        "title": title_name,
        "category": cat,
        "is_local": False,
        "image": img_url,
        "original_size": orig_s,
        "repack_size": rep_s,
        "arabic_status": "مدمج باللغة العربية والترجمة تلقائياً 100%",
        "download_url": f"magnet:?xt=urn:btih:{hash_code}&dn={title_name.replace(' ', '+')}&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce",
        "launcher_cmd": "",
        "featured": False,
        "description": f"تجميعة FitGirl المدمجة بالكامل لـ {title_name} مع اللغة العربية والترجمة المباشرة 100% برابط تورنت موحد."
    })

print(f"Generated total catalog size: {len(games_list)}")

with open("/home/yazan/VB_TITAN_Web/data/games.json", "w", encoding="utf-8") as f:
    json.dump(games_list, f, ensure_ascii=False, indent=2)

print("Saved 2,000 games database to data/games.json")
