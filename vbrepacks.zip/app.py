import os
import json
import subprocess
from flask import Flask, render_template, jsonify, request, send_from_directory

app = Flask(__name__, template_folder="templates", static_folder="static")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, "data", "games.json")
ASSETS_DIR = os.path.join(BASE_DIR, "assets")

# Admin credentials
ADMIN_PASSCODE = "vbtitan2026"

def load_games():
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_games(games):
    os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(games, f, ensure_ascii=False, indent=2)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/admin")
def admin_page():
    return render_template("admin.html")

@app.route("/manifest.json")
def serve_manifest():
    return send_from_directory(os.path.join(BASE_DIR, "static"), "manifest.json")

@app.route("/sw.js")
def serve_sw():
    return send_from_directory(os.path.join(BASE_DIR, "static"), "sw.js")

@app.route("/googlef49ba14b86e890ca.html")
def google_verification():
    return "google-site-verification: googlef49ba14b86e890ca.html", 200, {'Content-Type': 'text/html'}

@app.route("/robots.txt")
def serve_robots():
    content = "User-agent: *\nAllow: /\nSitemap: https://vbrepacks.onrender.com/sitemap.xml\n"
    return content, 200, {'Content-Type': 'text/plain'}

@app.route("/sitemap.xml")
def serve_sitemap():
    games = load_games()
    urls_xml = []
    base_domain = "https://vbrepacks.onrender.com"
    
    urls_xml.append(f"""  <url>
    <loc>{base_domain}/</loc>
    <priority>1.0</priority>
    <changefreq>daily</changefreq>
  </url>""")
    
    xml_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
{"\n".join(urls_xml)}
</urlset>"""
    return xml_content, 200, {'Content-Type': 'application/xml'}

@app.route("/assets/<path:filename>")
def serve_asset(filename):
    return send_from_directory(ASSETS_DIR, filename)


@app.route("/api/games", methods=["GET"])
def get_games():
    return jsonify(load_games())

@app.route("/api/games", methods=["POST"])
def add_game():
    data = request.json
    games = load_games()
    
    new_game = {
        "id": data.get("id") or f"game_{len(games)+1}",
        "title": data.get("title", "لعبة جديدة"),
        "category": data.get("category", "عام"),
        "image": data.get("image", "/assets/logo.png"),
        "original_size": data.get("original_size", "50 GB"),
        "repack_size": data.get("repack_size", "20 GB"),
        "arabic_status": data.get("arabic_status", "مدمج باللغة العربية تلقائياً 100%"),
        "download_links": {
            "torrent_magnet": data.get("torrent_magnet", "#"),
            "cloud_direct": data.get("cloud_direct", "#")
        },
        "launcher_cmd": data.get("launcher_cmd", ""),
        "featured": data.get("featured", False),
        "description": data.get("description", "لعبة معربة ومضغوطة ومدمجة بالكامل.")
    }
    games.insert(0, new_game)
    save_games(games)
    return jsonify({"success": True, "game": new_game})

@app.route("/api/games/<game_id>", methods=["DELETE"])
def delete_game(game_id):
    games = load_games()
    games = [g for g in games if g["id"] != game_id]
    save_games(games)
    return jsonify({"success": True})

@app.route("/api/launch/<game_id>", methods=["POST"])
def launch_game(game_id):
    games = load_games()
    game = next((g for g in games if g["id"] == game_id), None)
    
    if not game or not game.get("launcher_cmd"):
        return jsonify({"success": False, "error": "مسار التشغيل غير متاح لهذه اللعبة محلياً"}), 400
        
    cmd = game["launcher_cmd"]
    try:
        print(f"[VB] Launching game {game['title']} -> {cmd}")
        subprocess.Popen(
            cmd,
            shell=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True
        )
        return jsonify({"success": True, "message": f"تم تشغيل {game['title']} بنجاح!"})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=7777, debug=True)
